/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ages.types;

/**
 *
 * @author od
 */
public class HGeo {

    public int GID;
    
    public double RG1_max;
    public double RG2_max;
    public double RG1_k;
    public double RG2_k;
    public double RG1_active;
    public double Kf_geo;

    
}

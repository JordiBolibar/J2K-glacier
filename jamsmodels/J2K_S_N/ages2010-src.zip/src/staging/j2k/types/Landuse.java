/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package staging.j2k.types;


/**
 *
 * @author od
 */
public class Landuse {

    public int LID;
    public double albedo;
    // "Monthly stomata resistance values"
    public double[] RSC0;
    public double[] LAI;
    public double[] effHeight;
    public double  rootDepth;
    public double  sealedGrade;
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package staging.j2k.types;

/**
 *
 * @author od
 */
public class SoilType {

    public int SID;
    public double depth;

    public double kf_min;
    public double depth_min;
    public double kf_max;
    public double cap_rise;
    public double aircap;
    public double fc_sum;
    public double[] fc;

}
